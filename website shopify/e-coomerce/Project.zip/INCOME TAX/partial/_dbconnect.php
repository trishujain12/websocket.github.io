<?php
$servername="localhost";
$username="root";
$pswd="";
$database="myuser";

$con=mysqli_connect($servername,$username,$pswd,$database);


?>